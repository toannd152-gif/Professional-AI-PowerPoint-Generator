/*
============================================================

Markdown Parser

============================================================
*/

import { BaseParser } from "./baseParser.js";
import { readText } from "../utils.js";

export class MarkdownParser extends BaseParser {

    getSupportedExtensions() {

        return [

            ".md"

        ];

    }

    async parse(file) {

        const text = await readText(file);

        const document = this.createDocument();

        document.title = file.name;

        document.metadata = {

            type: "markdown"

        };

        document.pages.push({

            index:0,

            markdown:text

        });

        return document;

    }

}