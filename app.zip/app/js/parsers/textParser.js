/*
============================================================

Text Parser

============================================================
*/

import { BaseParser } from "./baseParser.js";
import { readText } from "../utils.js";

export class TextParser extends BaseParser {

    getSupportedExtensions() {

        return [

            ".txt"

        ];

    }

    async parse(file) {

        const text = await readText(file);

        const document = this.createDocument();

        document.title = file.name;

        document.metadata = {

            type: "text",

            name: file.name,

            size: file.size

        };

        document.pages.push({

            index: 0,

            content: text

        });

        return document;

    }

}