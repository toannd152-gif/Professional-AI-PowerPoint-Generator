/*
================================================

PDF Parser

================================================
*/

import pdfjsLib from "../config/pdfConfig.js";
import { readArrayBuffer } from "./pdfUtils.js";

export class PDFParser {

    async parse(file) {

        const buffer = await readArrayBuffer(file);

        const pdf = await pdfjsLib.getDocument({

            data: buffer

        }).promise;

        const document = {

            title: file.name,

            metadata: {

                fileName: file.name,

                fileSize: file.size,

                totalPages: pdf.numPages

            },

            pages: []

        };

        for (

            let pageNumber = 1;

            pageNumber <= pdf.numPages;

            pageNumber++

        ) {

            console.log(

                `Reading page ${pageNumber}/${pdf.numPages}`

            );

            const page = await pdf.getPage(pageNumber);

            const textContent =

                await page.getTextContent();

            const text =

                textContent.items

                    .map(item => item.str)

                    .join(" ");

            document.pages.push({

                pageNumber,

                text

            });

        }

        return document;

    }

}