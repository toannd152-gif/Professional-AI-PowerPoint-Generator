/*
============================================================

HTML Parser

============================================================
*/

import { BaseParser } from "./baseParser.js";
import { readText } from "../utils.js";

export class HTMLParser extends BaseParser {

    getSupportedExtensions() {

        return [

            ".html",

            ".htm"

        ];

    }

    async parse(file) {

        const html = await readText(file);

        const parser = new DOMParser();

        const dom = parser.parseFromString(

            html,

            "text/html"

        );

        const document = this.createDocument();

        document.title =

            dom.title ||

            file.name;

        document.metadata = {

            type:"html"

        };

        document.pages.push({

            index:0,

            html,

            text:dom.body.innerText

        });

        return document;

    }

}