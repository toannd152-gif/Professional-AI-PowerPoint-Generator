/*
================================================

Parser Manager

Routes a File / Blob to the right parser based on the
extension. PDF is loaded LAZILY because pdf.js is a
browser-only bundle — loading it eagerly would break the
Node-side integration test.

================================================
*/

import { TextParser } from "./textParser.js";
import { MarkdownParser } from "./markdownParser.js";
import { HTMLParser } from "./htmlParser.js";

export class ParserManager {

    constructor(options = {}) {

        this.textParser = new TextParser();
        this.markdownParser = new MarkdownParser();
        this.htmlParser = new HTMLParser();

        this.pdfParser = null;
        this.pdfParserLoader = options.pdfParserLoader || (async () => {

            const { PDFParser } = await import("./pdfParser.js");
            return new PDFParser();

        });

        this.logger = options.logger || null;

    }

    /**
     * Lazy access to the PDF parser — never instantiated
     * until somebody actually parses a .pdf file.
     */
    async _getPdfParser() {

        if (this.pdfParser) return this.pdfParser;

        this.pdfParser = await this.pdfParserLoader();

        return this.pdfParser;

    }

    /**
     * Parse document.
     */
    async parse(file) {

        const extension =
            (file.name || "")
                .split(".")
                .pop()
                .toLowerCase();

        switch (extension) {

            case "pdf": {

                const parser = await this._getPdfParser();
                return await parser.parse(file);

            }

            case "txt":
                return await this.textParser.parse(file);

            case "md":
            case "markdown":
                return await this.markdownParser.parse(file);

            case "html":
            case "htm":
                return await this.htmlParser.parse(file);

            default:
                throw new Error(`Unsupported file type: ${extension}`);

        }

    }

    /**
     * Returns the list of extensions this manager can route.
     */
    supportedExtensions() {

        return ["pdf", "txt", "md", "markdown", "html", "htm"];

    }

}