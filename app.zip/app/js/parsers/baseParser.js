/*
============================================================

Base Parser

============================================================
*/

export class BaseParser {

    constructor(store, events) {

        this.store = store;

        this.events = events;

    }

    /**
     * Supported extensions
     */
    getSupportedExtensions() {

        return [];

    }

    /**
     * Parse document
     */
    async parse(file) {

        throw new Error(

            "parse() must be implemented."

        );

    }

    /**
     * Build Internal Document Model
     */
    createDocument() {

        return {

            title: "",

            pages: [],

            metadata: {},

            assets: []

        };

    }

}