/**
 * Document Manager
 * Imports files through ParserManager into the store.
 */

import { ParserManager } from "./parsers/parserManager.js";

export class DocumentManager {

    constructor(store, events, logger = null) {

        this.store = store;
        this.events = events;
        this.logger = logger;

        this.parserManager = new ParserManager();

    }

    async import(file) {

        try {

            this.logger?.info("Import:", file.name);

            const doc = await this.parserManager.parse(file);

            this.store.set("document", doc);

            this.store.set("project", {
                name: doc.title.replace(/\.(pdf|txt|md|html?|markdown)$/i, "")
            });

            /*
            New document invalidates previous pipeline results.
            */
            this.store.set("analysis", null);
            this.store.set("slides", []);

            this.events.emit("document:parsed", doc);

            return doc;

        } catch (error) {

            this.logger?.error(error);

            this.events.emit("document:error", error);

            return null;

        }

    }

}
Successfully replaced 1 block(s) in /workspace/extracted/app/js/documentManager.js.