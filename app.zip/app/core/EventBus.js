/**
 * EventBus
 * Central event system.
 */

export class EventBus {

    constructor(logger = null) {

        this.logger = logger;

        this.events = new Map();

    }

    on(event, callback) {

        if (!this.events.has(event)) {

            this.events.set(event, new Set());

        }

        this.events.get(event).add(callback);

    }

    once(event, callback) {

        const wrapper = (payload) => {

            callback(payload);

            this.off(event, wrapper);

        };

        this.on(event, wrapper);

    }

    off(event, callback) {

        if (!this.events.has(event)) {

            return;

        }

        this.events.get(event).delete(callback);

    }

    emit(event, payload = null) {

        if (!this.events.has(event)) {

            return;

        }

        if (this.logger) {

            this.logger.debug(

                "[Event]",

                event,

                payload

            );

        }

        this.events
            .get(event)
            .forEach(listener => listener(payload));

    }

    clear() {

        this.events.clear();

    }

    listenerCount(event) {

        if (!this.events.has(event)) {

            return 0;

        }

        return this.events.get(event).size;

    }

    eventNames() {

        return [...this.events.keys()];

    }

}