# AI PPT Generator

Ứng dụng web hoàn chỉnh: biến tài liệu (PDF, TXT, MD, HTML) thành bài trình bày PowerPoint — chạy 100% trên trình duyệt, không cần server hay API bên ngoài.

## Chạy ứng dụng

```bash
npm install
npm run dev        # Vite dev server → http://localhost:5173
```

Hoặc không cần npm (pdf.js đã có sẵn trong `vendor/`):

```bash
python3 -m http.server 8000   # → http://localhost:8000
```

Chạy test:

```bash
npm test           # 12 bộ test (core + services + pptx)
```

## Quy trình 6 bước

1. **Upload** — Import PDF / TXT / MD / HTML (chọn file hoặc kéo thả), xem trước từng trang.
2. **AI Analysis** — Phân tích offline: nhận diện chương/mục, tách phần, trích từ khóa, thống kê (số từ, thời gian đọc).
3. **Slide Planner** — Tự tạo kế hoạch slide (slide tiêu đề → slide nội dung theo từng phần → slide tổng kết). Chỉnh sửa trực tiếp: đổi tiêu đề, sửa gạch đầu dòng, sắp xếp ↑↓, thêm/xóa slide. Hỗ trợ **Undo/Redo**.
4. **Rendering** — Xem trước slide 16:9 với 4 theme (Ocean, Minimal Light, Forest, Sunset), thanh thumbnail, điều hướng trước/sau.
5. **Validation** — Chấm điểm chất lượng (0–100), liệt kê lỗi/cảnh báo (thiếu tiêu đề, quá nhiều bullet, dòng quá dài...).
6. **Export** — Xuất **.pptx thật** (OOXML tự sinh, không cần thư viện — mở được bằng PowerPoint / Google Slides / Keynote), HTML slides độc lập, hoặc JSON dự án.

Thêm: Inspector (chi tiết + speaker notes cho slide đang chọn), Statusbar, thông báo toast, tìm kiếm trong slide (ô Search trên header), **Save/khôi phục dự án** qua localStorage, **Dark mode** trong Settings.

## Kiến trúc

```
core/                  Hạ tầng ứng dụng
  Bootstrap.js         Khởi tạo & đăng ký core services
  ServiceContainer.js  Dependency injection
  EventBus.js          Hệ thống sự kiện
  Store.js             State toàn cục (dot-path: store.get("ui.theme"))
  ModuleManager.js     Vòng đời module (initialize/start/stop/destroy)
  Logger.js            Logging theo cấp độ
  services/
    ConfigManager.js   Cấu hình (localStorage, deep-merge defaults)
    HistoryManager.js  Undo/Redo stacks

modules/               8 màn hình (mỗi module extends BaseModule)
  dashboardModule.js   uploadModule.js   analysisModule.js   plannerModule.js
  rendererModule.js    validationModule.js   exportModule.js   settingsModule.js

js/
  app.js               Entry: bootstrap core → đăng ký services → mount modules
  router.js            Điều hướng theo route
  documentManager.js   Import file qua ParserManager
  parsers/             PDF (pdf.js) / TXT / MD / HTML
  services/
    analyzer.js        Phân tích heuristic (sections, keywords, stats)
    slidePlanner.js    Sinh kế hoạch slide từ kết quả phân tích
    validator.js       Bộ luật kiểm tra chất lượng
    zipWriter.js       Ghi file ZIP thuần JS (CRC32, store)
    pptxExporter.js    Sinh OOXML .pptx thuần JS
    exporters.js       Xuất HTML / JSON + download helper
    themes.js          4 theme trình chiếu

components/            Header, Sidebar, Workspace (shell), Inspector, Statusbar, Notification
test/                  12 test chạy bằng Node (npm test)
vendor/pdfjs/          pdf.js bundle (chạy được không cần npm)
```

## Đã kiểm thử

- `npm test`: 12/12 bộ test đạt.
- E2E bằng Playwright: 16 bước (import → phân tích → sửa slide → undo/redo → render → validation → export) — 0 lỗi console.
- File .pptx xuất ra được xác thực bằng python-pptx và mở/render thành công bằng LibreOffice.
