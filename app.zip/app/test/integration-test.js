/**
 * Integration Test
 *
 * End-to-end happy path:
 *
 *   Upload (mock file)
 *      ↓
 *   Parser → RawDocument
 *      ↓
 *   DocumentModelBuilder → DocumentModel
 *      ↓
 *   KnowledgeBuilder → Knowledge
 *      ↓
 *   PresentationBuilder → Presentation (Slide[])
 *      ↓
 *   PptxExporter → Uint8Array (valid PPTX zip)
 *      ↓
 *   PresentationValidator → PASS
 *
 * Plus a Pipeline run that ties all the stages together.
 *
 * Run with `node test/integration-test.js` (via npm test).
 */

import { strict as assert } from "assert";

import { Logger, LogLevel } from "../core/Logger.js";
import { EventBus } from "../core/EventBus.js";
import { Store } from "../core/Store.js";
import { ServiceContainer } from "../core/ServiceContainer.js";

import { ParserManager } from "../js/parsers/parserManager.js";
import { DocumentModelBuilder } from "../js/builders/documentModelBuilder.js";
import { KnowledgeBuilder } from "../js/builders/knowledgeBuilder.js";
import { PresentationBuilder } from "../js/builders/presentationBuilder.js";

import { DocumentAnalyzer } from "../js/services/analyzer.js";
import { SlidePlanner } from "../js/services/slidePlanner.js";
import { PresentationValidator } from "../js/services/validator.js";
import { PptxExporter } from "../js/services/pptxExporter.js";
import { getTheme } from "../js/services/themes.js";

import {
    buildStandardPipeline,
    PIPELINE_STATUS,
    STAGE_STATUS
} from "../js/workflow/index.js";

import { RawDocument } from "../models/RawDocument.js";
import { DocumentModel } from "../models/DocumentModel.js";
import { Knowledge } from "../models/Knowledge.js";
import { Presentation } from "../models/Presentation.js";

import {
    PerformanceMonitor
} from "../core/services/PerformanceMonitor.js";

/* ---------- helpers ---------- */

const logger = new Logger(LogLevel.WARN);
const events = new EventBus(logger);
const store = new Store(events, logger);
const container = new ServiceContainer(logger);
const perf = new PerformanceMonitor({ logger, events });

container.register("logger", logger);
container.register("eventBus", events);
container.register("store", store);
container.register("performanceMonitor", perf);

/* ---------- build pipeline ---------- */

const parserManager = new ParserManager();
const documentModelBuilder = new DocumentModelBuilder();
const knowledgeBuilder = new KnowledgeBuilder();
const presentationBuilder = new PresentationBuilder();
const analyzer = new DocumentAnalyzer();
const planner = new SlidePlanner();
const validator = new PresentationValidator();
const exporter = new PptxExporter();

/* ---------- mock file ---------- */

function mockTextFile(name = "integration.txt") {

    return {
        name,
        size: 4096,
        type: "text/plain",
        async text() { return mockTextFile.body; }
    };

}

mockTextFile.body = [
    "CHƯƠNG 1: GIỚI THIỆU",
    "Dân quân tự vệ là lực lượng vũ trang quần chúng. Lực lượng này không thoát ly sản xuất, gắn liền với nhân dân.",
    "",
    "CHƯƠNG 2: NHIỆM VỤ",
    "Sẵn sàng chiến đấu bảo vệ địa phương. Phối hợp với các đơn vị khác trong các tình huống khẩn cấp.",
    "",
    "CHƯƠNG 3: TỔ CHỨC",
    "Đội ngũ cán bộ gồm ba cấp: xã, huyện, tỉnh. Mỗi cấp phụ trách một vùng lãnh thổ cụ thể."
].join("\n");

/* ---------- test ---------- */

async function runIntegration() {

    logger.info("[Integration] starting");

    /* 1. Upload (mock) */

    const file = mockTextFile();

    /* 2. Parser → RawDocument */

    const raw = await parserManager.parse(file);

    assert.ok(raw instanceof RawDocument, "Parser should produce a RawDocument");
    assert.equal(raw.format, "txt", "Format should be detected");
    assert.ok(raw.pageCount >= 1, "Should have at least one page");

    /* 3. DocumentModelBuilder → DocumentModel */

    const model = documentModelBuilder.build(raw);

    assert.ok(model instanceof DocumentModel, "Builder should produce a DocumentModel");
    assert.ok(model.validate(), "DocumentModel should be valid");
    assert.ok(model.sectionCount >= 3, "Should detect all 3 chapters");

    /* 4. KnowledgeBuilder → Knowledge */

    const knowledge = knowledgeBuilder.build(model, model.title);

    assert.ok(knowledge instanceof Knowledge, "Should produce a Knowledge model");
    assert.ok(knowledge.statistics.words > 30, "Should count words");
    assert.ok(knowledge.keywords.length > 0, "Should extract keywords");
    assert.ok(knowledge.summary.length > 0, "Should produce a summary");

    /* 5. PresentationBuilder → Presentation */

    const presentation = presentationBuilder.build({
        knowledge,
        documentModel: model,
        title: "Bài Trình Bày Tích Hợp"
    });

    assert.ok(presentation instanceof Presentation, "Should produce a Presentation");
    assert.ok(presentation.slideCount >= 4, "Title + 3 sections + summary");
    assert.ok(presentation.titleSlide, "Should have a title slide");
    assert.ok(presentation.slides.every(s => s.title && s.title.length > 0), "Every slide has a title");

    /* 6. PptxExporter → Uint8Array (valid PPTX) */

    const theme = getTheme(presentation.themeId);

    const legacySlides = presentation.slides.map(s => ({
        id: s.id,
        type: s.type,
        title: s.title,
        subtitle: s.subtitle,
        bullets: s.bullets,
        notes: s.notes,
        layout: s.layout
    }));

    const bytes = exporter.build(legacySlides, theme, {
        title: presentation.title,
        author: presentation.author
    });

    /* ZIP magic: PK\x03\x04 */

    assert.equal(bytes[0], 0x50, "PPTX must start with PK zip magic");
    assert.equal(bytes[1], 0x4B, "PPTX must have PK zip magic");
    assert.equal(bytes[2], 0x03);
    assert.equal(bytes[3], 0x04);
    assert.ok(bytes.length > 5_000, "PPTX should be non-trivial size");

    /* 7. PresentationValidator → PASS */

    const report = validator.validate(legacySlides);

    assert.equal(report.passed, true, "Validator should pass the auto-generated deck");
    assert.ok(report.score >= 80, "Validator should give a high score");

    /* 8. Pipeline run */

    const pipeline = buildStandardPipeline({
        parserManager,
        documentModelBuilder,
        knowledgeBuilder,
        presentationBuilder,
        analyzer,
        planner,
        renderer: null,
        exporter,
        eventBus: events,
        logger
    });

    const ctx = await pipeline.run({ file });

    assert.equal(pipeline.status, PIPELINE_STATUS.COMPLETED, "Pipeline should complete");
    assert.ok(ctx.raw, "Pipeline should produce RawDocument");
    assert.ok(ctx.documentModel, "Pipeline should produce DocumentModel");
    assert.ok(ctx.knowledge, "Pipeline should produce Knowledge");
    assert.ok(ctx.presentation, "Pipeline should produce Presentation");
    assert.ok(ctx.export?.bytes, "Pipeline should produce PPTX bytes");

    /* All stages should be completed */

    for (const task of pipeline.tasks) {

        for (const stage of task.stages) {

            assert.equal(
                stage.status,
                STAGE_STATUS.COMPLETED,
                `Stage ${task.id}/${stage.id} should be COMPLETED (got ${stage.status})`
            );

        }

    }

    /* Performance monitor should have at least one timing */

    const snap = perf.snapshot();

    assert.ok(snap.timings.pipeline, "Performance monitor should record pipeline timing");

    /* Integration success */

    logger.info(`[Integration] OK (${pipeline.duration()}ms, ${bytes.length} bytes, ${presentation.slideCount} slides)`);

    console.log("integration-test OK:", {
        pipelineStatus: pipeline.status,
        pipelineDurationMs: pipeline.duration(),
        pptxBytes: bytes.length,
        slideCount: presentation.slideCount,
        score: report.score,
        perfTimings: Object.keys(snap.timings).length
    });

}

await runIntegration();