import { ConfigManager } from "../core/services/ConfigManager.js";

const config = new ConfigManager();

console.log(config.get("ui.theme"));

config.set("ui.theme", "dark");

console.log(config.get("ui.theme"));

config.save();

config.load();

console.log(config.get("ui.theme"));