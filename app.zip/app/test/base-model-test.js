import { BaseModel } from "../models/BaseModel.js";

const model = new BaseModel();

console.log(model.getId());

model.setMetadata("author", "Toàn");

console.log(model.getMetadata("author"));

console.log(model.serialize());

console.log(model.validate());