import { Logger, LogLevel } from "../core/Logger.js";
import { EventBus } from "../core/EventBus.js";

const logger = new Logger(LogLevel.DEBUG);

const bus = new EventBus(logger);

bus.on("hello", (data) => {

    logger.info("Received:", data);

});

bus.emit("hello", {

    message: "AI PPT Generator"

});