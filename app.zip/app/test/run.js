/**
 * Test Runner — run with:  npm test
 *
 * Two categories:
 *
 *   - UNIT tests          (pure, no dependencies between them)
 *   - INTEGRATION tests   (full pipeline: Parser → … → PPTX)
 *
 * Integration tests run LAST so a broken unit test doesn't
 * hide a regression in the pipeline.
 */

const unitTests = [
    "./logger-test.js",
    "./eventbus-test.js",
    "./store-test.js",
    "./container-test.js",
    "./config-manager-test.js",
    "./module-manager-test.js",
    "./bootstrap-test.js",
    "./base-model-test.js",
    "./analyzer-test.js",
    "./planner-test.js",
    "./validator-test.js",
    "./pptx-test.js"
];

const integrationTests = [
    "./integration-test.js"
];

const all = [...unitTests, ...integrationTests];

let failed = 0;
let integrationFailed = 0;

for (const file of all) {

    try {

        await import(file);

        console.log(`✔ ${file}`);

    } catch (error) {

        failed++;

        if (integrationTests.includes(file)) integrationFailed++;

        console.error(`✖ ${file}`);
        console.error(" ", error.stack || error.message);

    }

}

console.log("");

if (failed === 0) {

    console.log(`ALL TESTS PASSED  (${unitTests.length} unit + ${integrationTests.length} integration)`);

} else {

    console.log(
        `${failed} TEST(S) FAILED  ` +
        `(unit: ${unitTests.length - (failed - integrationFailed)}/${unitTests.length}, ` +
        `integration: ${integrationTests.length - integrationFailed}/${integrationTests.length})`
    );

}

process.exit(failed === 0 ? 0 : 1);