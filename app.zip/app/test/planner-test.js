import { DocumentAnalyzer } from "../js/services/analyzer.js";
import { SlidePlanner } from "../js/services/slidePlanner.js";
import { strict as assert } from "assert";

const doc = {
    title: "demo.txt",
    pages: [{
        index: 0,
        content: "PHẦN MỘT\nCâu thứ nhất của phần một. Câu thứ hai của phần một.\n\nPHẦN HAI\nNội dung phần hai rất quan trọng."
    }]
};

const analysis = new DocumentAnalyzer().analyze(doc);
const slides = new SlidePlanner().plan(analysis);

assert.equal(slides[0].type, "title");
assert.ok(slides.length >= 3);
assert.ok(slides[1].bullets.length >= 1);
assert.ok(slides.every(s => s.id));

console.log("planner-test OK:", slides.length, "slides");
