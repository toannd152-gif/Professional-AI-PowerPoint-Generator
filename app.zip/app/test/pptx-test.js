import { PptxExporter } from "../js/services/pptxExporter.js";
import { getTheme } from "../js/services/themes.js";
import { strict as assert } from "assert";

const slides = [
    { id: "1", type: "title", title: "Tiêu đề & <đặc biệt>", subtitle: "phụ đề", bullets: [] },
    { id: "2", type: "content", title: "Nội dung", subtitle: "", bullets: ["một", "hai"] }
];

const bytes = new PptxExporter().build(slides, getTheme("ocean"), { title: "t" });

/* ZIP magic: PK\x03\x04 */
assert.equal(bytes[0], 0x50);
assert.equal(bytes[1], 0x4B);
assert.equal(bytes[2], 0x03);
assert.equal(bytes[3], 0x04);
assert.ok(bytes.length > 5000);

console.log("pptx-test OK:", bytes.length, "bytes");
