import { DocumentAnalyzer } from "../js/services/analyzer.js";
import { strict as assert } from "assert";

const doc = {
    title: "test.txt",
    pages: [{
        index: 0,
        content: "CHƯƠNG 1: GIỚI THIỆU\nDân quân tự vệ là lực lượng vũ trang quần chúng. Lực lượng này không thoát ly sản xuất.\n\nCHƯƠNG 2: NHIỆM VỤ\nSẵn sàng chiến đấu bảo vệ địa phương. Phối hợp với các đơn vị khác."
    }]
};

const analysis = new DocumentAnalyzer().analyze(doc);

assert.equal(analysis.title, "test");
assert.equal(analysis.sections.length, 2);
assert.ok(analysis.sections[0].title.includes("GIỚI THIỆU"));
assert.ok(analysis.keywords.length > 0);
assert.ok(analysis.stats.words > 10);

console.log("analyzer-test OK");
