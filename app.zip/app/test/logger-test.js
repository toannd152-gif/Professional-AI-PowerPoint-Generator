import { Logger, LogLevel } from "../core/Logger.js";

const logger = new Logger(LogLevel.DEBUG);

logger.debug("Debug");

logger.info("Info");

logger.warn("Warning");

logger.error("Error");