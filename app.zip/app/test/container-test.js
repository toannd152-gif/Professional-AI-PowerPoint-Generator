import { Logger, LogLevel } from "../core/Logger.js";
import { EventBus } from "../core/EventBus.js";
import { Store } from "../core/Store.js";
import { ServiceContainer } from "../core/ServiceContainer.js";

const logger = new Logger(LogLevel.DEBUG);

const bus = new EventBus(logger);

const store = new Store(bus, logger);

const container = new ServiceContainer(logger);

container.register("logger", logger);
container.register("eventBus", bus);
container.register("store", store);

console.log(container.resolve("logger") === logger);
console.log(container.resolve("eventBus") === bus);
console.log(container.resolve("store") === store);