import { Logger, LogLevel } from "../core/Logger.js";
import { EventBus } from "../core/EventBus.js";
import { Store } from "../core/Store.js";

const logger = new Logger(LogLevel.DEBUG);

const bus = new EventBus(logger);

const store = new Store(bus, logger);

store.subscribe((change) => {

    logger.info("Store Changed", change);

});

store.set(

    "ui.theme",

    "dark"

);

console.log(

    store.get("ui.theme")

);