import { Logger, LogLevel } from "../core/Logger.js";
import { ModuleManager } from "../core/ModuleManager.js";
import { BaseModule } from "../core/BaseModule.js";

class DemoModule extends BaseModule {

    constructor() {

        super("Demo");

    }

    async initialize() {

        await super.initialize();

        console.log("Initialize");

    }

    async start() {

        await super.start();

        console.log("Start");

    }

    async stop() {

        await super.stop();

        console.log("Stop");

    }

    async destroy() {

        await super.destroy();

        console.log("Destroy");

    }

}

const logger = new Logger(LogLevel.INFO);

const manager = new ModuleManager(logger);

manager.register(new DemoModule());

await manager.initializeAll();

await manager.startAll();

await manager.stopAll();

await manager.destroyAll();