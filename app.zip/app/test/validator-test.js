import { PresentationValidator } from "../js/services/validator.js";
import { strict as assert } from "assert";

const validator = new PresentationValidator();

const empty = validator.validate([]);
assert.equal(empty.passed, false);

const good = validator.validate([
    { type: "title", title: "Demo", bullets: [] },
    { type: "content", title: "A", bullets: ["x", "y"] },
    { type: "content", title: "B", bullets: ["z"] }
]);
assert.equal(good.passed, true);
assert.ok(good.score >= 80);

const bad = validator.validate([
    { type: "content", title: "", bullets: [] }
]);
assert.ok(bad.errors >= 1);
assert.equal(bad.passed, false);

console.log("validator-test OK");
