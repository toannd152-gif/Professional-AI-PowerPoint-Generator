import { Bootstrap } from "../core/Bootstrap.js";

const bootstrap = new Bootstrap();

bootstrap.initialize();

const container =

    bootstrap.getContainer();

console.log(

    container.has("logger")

);

console.log(

    container.has("eventBus")

);

console.log(

    container.has("store")

);

console.log(

    container.has("moduleManager")

);